# Information Visulalization

 >Final plots: submitting project.
>  merginf in the main index.html file
